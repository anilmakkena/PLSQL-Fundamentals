

BEGIN
  update_dept;
END;
/
call update_dept();

exec update_dept();

execute update_dept();

